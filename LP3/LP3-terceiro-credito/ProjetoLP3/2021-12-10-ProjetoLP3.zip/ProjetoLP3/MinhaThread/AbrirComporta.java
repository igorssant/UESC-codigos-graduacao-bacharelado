package ProjetoLP3.MinhaThread;

import ProjetoLP3.Barragem.BarragemConcreta;
import java.util.logging.Level;
import java.util.logging.Logger;
import ProjetoLP3.menu.MenuGerenciadorRios;
import java.util.Scanner;

public class AbrirComporta implements Runnable {
    
    private BarragemConcreta barragem;
    private int tempo;
    private float numeroDeComportas;
    private boolean fechaOuAbre;
    private MenuGerenciadorRios gerenciadorRios;
    
    public AbrirComporta (int tempo, int numeroDeComportas, MenuGerenciadorRios gerenciadorRios) {
        
        this.tempo = tempo;
        this.numeroDeComportas = numeroDeComportas;
        this.gerenciadorRios = gerenciadorRios;
    }

    public void setBarragem (BarragemConcreta barragem)
    {
        this.barragem = barragem;
    }
    
    public void abrirComporta () {
        
        int quantidade = 0;
        
        System.out.println (this.numeroDeComportas + " foram abertas na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                Thread.sleep (100 * tempo);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "diminuiu para " + barragem.getNivelLago ());
    }
    
    public void fecharComporta () {
        
        System.out.println (this.numeroDeComportas + " foram fechadas na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                Thread.sleep (1000 * tempo);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        if (barragem.getVazao() > 0)
            System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "diminuiu para " + barragem.getNivelLago ());
        
        else
            System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "aumentou para " + barragem.getNivelLago ());
    }
    
    @Override
    public void run () {
        
        if (fechaOuAbre == true) {
            
            abrirComporta ();
            //gerenciadorDeRios.
        }
        else
            fecharComporta ();
        
    }

    public void menu () {
        
        BarragemConcreta barragemConcreta = this.gerenciadorRios.selecionarBarragem ();
        this.setBarragem (barragemConcreta);
        Thread threadComporta = new Thread (this);
        Scanner leitura = new Scanner (System.in);
        
        System.out.print ("Deseja abrir ou fecha a barragem?\n" +
                "true para abrir\n" +
                "false para fechar\n> ");
        
        fechaOuAbre = leitura.nextBoolean ();
        
        threadComporta.start ();
    }

}