package ProjetoLP3.Rio;

import java.util.ArrayList;
import ProjetoLP3.Barragem.BarragemConcreta;
import ProjetoLP3.Relatorio.Relatorio;
import ProjetoLP3.MinhaThread.Chuvas;

public class Rio
{      
   // private float volume;
   // private final float volumeMaximo;

    private String nome;
    Chuvas chuvas;

    private ArrayList<BarragemConcreta> barragens;
    private Relatorio meuRelatorio;
    
    public Rio(String nome)
    {
     //   this.barragens = new ArrayList<BarragemConcreta>();
     this.nome = nome;
     this.meuRelatorio = new Relatorio(this);
     this.barragens = new ArrayList<BarragemConcreta>();
    }

    public Relatorio getMeuRelatorio()
    {
        return this.meuRelatorio;
    }

    public void setRioNome(String nome)
    {
        this.nome = nome;
    }

    public String getRioNome()
    {
        return this.nome;
    }

    //Adiciona água aos lagos das barragens.
  /*  public void Chover(float quantidade)
    {
        for(BarragemConcreta barragem : barragens)
        {
           float atual = barragem.getNivelLago();
           barragem.setNivelLago(atual + quantidade);
       //    this.volume += (atual + quantidade);
        }

        //Verifica se houve excedentes.
        this.fluxoDeAgua();
    }*/

    public float Chover (float quantidade, int barragem) {
        
        return this.barragens.get(barragem).setNivelLago(quantidade);
    }

    /*public float volumeAtual()
    {
        return this.volume;
    }*/

    //Pega a lista de todas as barragens construídas no rio.
    public  ArrayList<BarragemConcreta>listarBarragens()
    {
        return this.barragens;
    }

    //Adiciona nova barragem ao rio.
    public void addBarragem(BarragemConcreta barragem)
    {
        this.barragens.add(barragem);
    }

    //Adiciona nova barragem numa posição específica no rio.
    public void addBarragem(int posicao, BarragemConcreta barragem)
    {
        this.barragens.add(posicao, barragem);
    }

    //Remove uma barragem em uma possição no rio.
    public void removeBarragem(int posicao)
    {
        this.barragens.remove(posicao);
    }

    //Remove uma barragem do rio.
    public void removeBarragem(BarragemConcreta barragem)
    {
        this.barragens.remove(barragem);
    }

    public float consumoTotal()
    {
        float consumoTotal = 0;

        for(BarragemConcreta barragemConcreta : barragens)
        {
            consumoTotal += barragemConcreta.getConsumo();
        }

        return consumoTotal;
    }
    
    public float abrirComportas(int barragem, int comportas)
    {
        this.barragens.get(barragem).abrirComportas(comportas);
        float vazao = this.barragens.get(barragem).getVazao();

        return this.barragens.get(barragem).setNivelLago(-vazao);
    }

    public float fecharComportas(int barragem, int comportas)
    {
        this.barragens.get(barragem).fecharComportas(comportas);
    
        return this.barragens.get(barragem).getVazao();
    }
    
}