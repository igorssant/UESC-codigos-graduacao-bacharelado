package ProjetoLP3;

import ProjetoLP3.GerenciadorDeFluxo.GerenciadorDeFluxo;
import ProjetoLP3.MinhaThread.AbrirComporta;
import ProjetoLP3.MinhaThread.Chuvas;
import ProjetoLP3.menu.*;
import ProjetoLP3.Relatorio.Relatorio;
import ProjetoLP3.Rio.Rio;
import java.util.Scanner;

public class App {
    
    private GerenciadorDeFluxo gerenciador;
    private MenuGerenciadorRios menuGerenciadorRios;
    private Relatorio relatorio;
    private MenuRelatorio menuRelatorio;
    private Runnable chuvas;
    private Runnable comportas;
    
    public App () {
        
        this.gerenciador = new GerenciadorDeFluxo ();
        this.menuGerenciadorRios = new MenuGerenciadorRios (gerenciador);
    }

    public void verGerenciador () {
        
        this.menuGerenciadorRios.menu();
    }
    
    public void estaChovendo (int tempo, float quantidade) {
        
        this.chuvas = new Chuvas (tempo, quantidade, menuGerenciadorRios);
    }
    
    public void comportas (int tempo, int numeroDeComportas) {
        
        this.comportas = new AbrirComporta (tempo, numeroDeComportas, menuGerenciadorRios);
    }

    public void verRelatorio () {
        
        int rio = 0;
        Scanner entrada = new Scanner (System.in);

        System.out.println ("Selecione o rio:");

        this.menuGerenciadorRios.printRios ();
        System.out.print (">");
        rio = entrada.nextInt ();

        this.relatorio = new Relatorio (gerenciador.getRio (rio));
        this.menuRelatorio = new MenuRelatorio (relatorio);

        menuRelatorio.menu ();
    }

    public static void main (String [] args) {
        
        int opcao = 0, tempo = 0, comportas = 0;
        float quantidadeDeChuva = 0f;
        Scanner entrada = new Scanner (System.in);
        App app = new App ();

        do {
            
            System.out.print ("1) Para Gerenciar os Rios\n2) Para ver os relatórios das barragens\n" +
            "3) Chover\n4)Abrir ou fechar comporta de uma barragem\n5) Sair\n> ");
            opcao = entrada.nextInt ();

            switch (opcao) {
                
                case 1:
                    
                    app.verGerenciador ();
                    break;

                case 2:
                   
                    app.verRelatorio ();
                    break;

                case 3:
                    
                    System.out.print ("Digite o tempo de chuva\n> ");
                    tempo = entrada.nextInt ();
                    
                    if (entrada.hasNextLine ())
                        entrada.nextInt ();
                                
                    System.out.print ("Digite o volume de chuva\n> ");
                    quantidadeDeChuva = entrada.nextFloat ();
                    
                    app.estaChovendo (tempo, quantidadeDeChuva);
                    break;
                    
                case 4:
                    
                    System.out.print ("Digite o tempo de abertura ou fechamento\n> ");
                    tempo = entrada.nextInt ();
                    
                    if (entrada.hasNextLine ())
                        entrada.nextInt ();
                                
                    System.out.print ("Digite o numero de comportas\n> ");
                    comportas = entrada.nextInt ();
                    
                    app.comportas (tempo, comportas);
                    break;
                    
                case 5:
                    break;

                default:
                    
                    System.out.println ("Opção incorreta");
            }
            
        } while (opcao != 5);
    }
}