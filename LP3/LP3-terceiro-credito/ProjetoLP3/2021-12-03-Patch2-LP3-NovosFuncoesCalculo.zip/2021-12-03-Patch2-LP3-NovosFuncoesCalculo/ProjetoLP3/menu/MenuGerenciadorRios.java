package ProjetoLP3.menu;

import ProjetoLP3.Rio.Rio;
import ProjetoLP3.GerenciadorDeFluxo.*;
import java.util.Scanner;
import ProjetoLP3.Barragem.*;

import java.util.Scanner;

public class MenuGerenciadorRios
{
    private GerenciadorDeFluxo gerenciadorDeFluxo;

    public MenuGerenciadorRios(GerenciadorDeFluxo gerenciadorDeFluxo)
    {
        this.gerenciadorDeFluxo = gerenciadorDeFluxo;
    }

    public void adicionarRios()
    {   
        System.out.println("Digite o nome do novo Rio");
        Scanner input = new Scanner(System.in);

        String nome = input.nextLine();

        Rio novoRio = new Rio(nome);

        gerenciadorDeFluxo.adicionarRio(novoRio);
    }

    public void removerRio()
    {
        System.out.println("Digite o indice do rio");
        int indice = 0;

        this.printRios();

        Scanner input = new Scanner(System.in);
        int index = input.nextInt();

        gerenciadorDeFluxo.removerRio(index);

    }

    public void printRios()
    {
        for(int indice = 0; indice <  gerenciadorDeFluxo.getRios().size(); ++indice)
        {
            System.out.println("[" + indice + "]" + gerenciadorDeFluxo.getRios().get(indice).getRioNome());
        }
    }

    public void adicionarBarragem()
    {   
        Scanner input = new Scanner(System.in);

        System.out.println("Digite o nome da barragem");
        String nome = input.nextLine();

        System.out.println("Digite o número do comportas");
        int numeroDeComportas = input.nextInt();

        System.out.println("Digite o nível do lago");
        float nivelDoLago = input.nextFloat();

        System.out.println("Digite a vazão das comportas");
        float vazaoDaBarragem = input.nextFloat();

        System.out.println("Digite o volume máximo do lago");
        float maximoLago = input.nextFloat();

        BarragemConcreta novBarragem = new BarragemConcreta(3, numeroDeComportas, nivelDoLago, vazaoDaBarragem, 0, maximoLago, nome);

        int indice = 0;
        this.printRios();

        System.out.println("Selecione o rio");
        indice = input.nextInt();

        this.gerenciadorDeFluxo.getRio(indice).addBarragem(indice, novBarragem);;

    }

    public void menu()
    {   
        int opcao = 0;
        Scanner entrada = new Scanner(System.in);

        System.out.print("1)Para adicionar um novo rio\n2)Para adicionar uma barragem a um rio"+
        "\n3)Para ver os rios cadastrados\n4)Para remover um rio\n5)Para sair\n>");

        opcao = entrada.nextInt();

        switch(opcao)
        {
            case 1:
            this.adicionarRios();
            break;

            case 2:
            this.adicionarBarragem();
            break;

            case 3:
            this.printRios();
            break;

            case 4:
            this.removerRio();
            break;

            case 5:
            return;

        }

    }
}