package ProjetoLP3;

import ProjetoLP3.GerenciadorDeFluxo.GerenciadorDeFluxo;
import ProjetoLP3.menu.*;
import ProjetoLP3.Relatorio.Relatorio;
import ProjetoLP3.Rio.Rio;

public class App2 {
    
    public static void main (String[] args) throws Exception {
        
        GerenciadorDeFluxo gerenciador = new GerenciadorDeFluxo ();
        Relatorio relatorio;
        MenuGerenciadorRios gerenciadorRio = new MenuGerenciadorRios (gerenciador);
        MenuRelatorio menuRelatorio;
        
        gerenciadorRio.adicionarRios ();
        gerenciadorRio.printRios ();
        relatorio = new Relatorio (gerenciador.getRio(0));
        menuRelatorio = new MenuRelatorio (relatorio);
    }
}