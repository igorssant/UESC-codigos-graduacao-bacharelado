package ProjetoLP3.Barragem;

public class BarragemConcreta implements Barragem {

    private int comportasAbertas;
    private int numeroDeComportas;
    private float nivelDoLago;
    private float vazaoDaBarragem;
    private float consumoDeAgua;
    private final int minimoDeComportasBarragem = 3;
    private final int maximoDeComportasAbertas = 10;
    private final int minimoDeComportasAbertas = 3;
    private final float metrosCubicos = 0.5f;
    private final float paraLitros = 1000.0f;
    private float maximoLago;
    
    private String nome;

    public BarragemConcreta (float maximoLago) {this.maximoLago = maximoLago;} // Construtor Vazio
    
    public BarragemConcreta (int comportasAbertas, int numeroDeComportas, float nivelDoLago, float vazaoDaBarragem, float consumoDeAgua, float maximoLago, String nome) {
        
        this.comportasAbertas = comportasAbertas;
        this.numeroDeComportas = numeroDeComportas;
        this.nivelDoLago = nivelDoLago;
        this.vazaoDaBarragem = vazaoDaBarragem;
        this.consumoDeAgua = consumoDeAgua;
        this.maximoLago = maximoLago;
        this.nome = nome;
    }

    public void setNomeBarragem(String nome)
    {
        this.nome = nome;
    }

    public String getNomeBarragem()
    {
        return this.nome;
    }
    
    @Override
    public float abrirComportas (int numero) {
        
        //Caso o número de comportas solicitas for maior que a quantidade disponível.
        if (this.comportasAbertas >= maximoDeComportasAbertas) {
            
            return -1;
        }
        
        this.comportasAbertas += numero;

        float saida = this.comportasAbertas * this.getVazao();

        //Diminui a quantidade de água do lago.
        this.setNivelLago(-saida);

        //Atualiza o consumo de água.
        this.setConsumo(this.getConsumo()); 
        
        //A quantidade de água liberada é igual ao número de comportas abertas * a vazão de cada comporta.
        return saida;

    }

    @Override
    public void fecharComportas (int numero) {
        
        float vazaoNula = 0;
        
        //Só fecha comportas se o número atual for maior que o número mínimo aberto.
        if (this.comportasAbertas <= minimoDeComportasAbertas) {
            
            return ;
        }
        
        this.comportasAbertas -= numero;
        
        if (this.comportasAbertas == 0) {
            
            setVazao (vazaoNula);
        } 
        //Atualiza o consumo de água.
        this.setConsumo(this.getConsumo()); 
    }

    public int quantidadeComportas()
    {
        return this.comportasAbertas;
    }

    @Override
    public void adicionarComporta (int numero) {
        
        if (numero < 1) {
            
            System.out.println ("Erro!!!\nNão é possível adicionar barragens com número negativo (ou nulo).");
            return ;
        }
        
        this.numeroDeComportas += numero; 
    }

    @Override
    public void removeComporta (int numero) {
        
        if (numero < 1) {
            
            System.out.println ("Erro!!!\nNão é possível retirar barragens com número negativo (ou nulo).");
            return ;
        }
        
        else if (numeroDeComportas <= minimoDeComportasBarragem) {
            
            System.out.println ("Erro!!!\nNão é possível retirar mais comportas dessa barragem.");
            return ;
        }
        
        this.numeroDeComportas -= numero;  
    }

    @Override
    public float getNivelLago () {
        
        return this.nivelDoLago;
    }

    @Override
    public float setNivelLago (float quantidade) {
        
        //A função só adiciona água, embora avise que há excesso, ela reitira.
        this.nivelDoLago += quantidade;

        if (this.nivelDoLago > this.maximoLago)
        {
            //Retornamos o excesso para cálculo futuro.
            return (this.nivelDoLago - quantidade);
        }

        float quinzePorcento = (this.maximoLago * 15) / 100;

        if(this.nivelDoLago < quinzePorcento)
        {
            return -1;
        }

        else
        {
            return 0;
        }
    }

    @Override
    public float getVazao () {
        
        this.vazaoDaBarragem = comportasAbertas * metrosCubicos; // transforma para litros
        return this.vazaoDaBarragem; // retorna em litros
    }

    @Override
    public void setVazao (float vazao) {
        
        this.vazaoDaBarragem = vazao;
    }

    @Override
    public float getConsumo () {
        
        this.consumoDeAgua = this.vazaoDaBarragem * paraLitros;
        return consumoDeAgua * comportasAbertas;
    }

    @Override
    public void setConsumo (float consumo) {
        
        this.consumoDeAgua = consumo;
    }
    
    @Override
    public float getVolumeMaximoDoLago () {
        
        return this.maximoLago;
    }
}