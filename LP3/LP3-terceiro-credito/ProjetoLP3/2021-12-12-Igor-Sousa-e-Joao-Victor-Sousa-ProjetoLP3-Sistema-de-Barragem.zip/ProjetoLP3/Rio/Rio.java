package ProjetoLP3.Rio;

import java.util.ArrayList;
import ProjetoLP3.Barragem.BarragemConcreta;
import ProjetoLP3.Relatorio.Relatorio;
import ProjetoLP3.MinhaThread.Chuvas;

public class Rio
{      
    private String nome;
    Chuvas chuvas;

    private ArrayList<BarragemConcreta> barragens;
    private Relatorio meuRelatorio;
    
    public Rio(String nome)
    {
     //   this.barragens = new ArrayList<BarragemConcreta>();
     this.nome = nome;
     this.meuRelatorio = new Relatorio(this);
     this.barragens = new ArrayList<BarragemConcreta>();
    }

    public Relatorio getMeuRelatorio()
    {
        return this.meuRelatorio;
    }

    public void setRioNome(String nome)
    {
        this.nome = nome;
    }

    public String getRioNome()
    {
        return this.nome;
    }

    public float Chover (float quantidade, int barragem) {
        
        return this.barragens.get(barragem).setNivelLago(quantidade);
    }

    //Pega a lista de todas as barragens construídas no rio.
    public  ArrayList<BarragemConcreta>listarBarragens () {
        
        return this.barragens;
    }

    //Adiciona nova barragem ao rio.
    public void addBarragem(BarragemConcreta barragem)
    {
        this.barragens.add(barragem);
    }

    //Adiciona nova barragem numa posição específica no rio.
    public void addBarragem(int posicao, BarragemConcreta barragem)
    {
        this.barragens.add(posicao, barragem);
    }

    //Remove uma barragem em uma possição no rio.
    public void removeBarragem(int posicao)
    {
        this.barragens.remove(posicao);
    }

    //Remove uma barragem do rio.
    public void removeBarragem(BarragemConcreta barragem)
    {
        this.barragens.remove(barragem);
    }

    public float consumoTotal()
    {
        float consumoTotal = 0;

        for(BarragemConcreta barragemConcreta : barragens)
        {
            consumoTotal += barragemConcreta.getConsumo();
        }

        return consumoTotal;
    }
    
    public float abrirComportas (int barragem, int comportas)
    {
        this.barragens.get(barragem).abrirComportas(comportas);
        float vazao = this.barragens.get(barragem).getVazao();

        return this.barragens.get (barragem).setNivelLago (-vazao);
    }

    public void fecharComportas (int barragem, int comportas, int tempo) {
        
        this.barragens.get (barragem).fecharComportas (comportas);
        //return this.barragens.get (barragem).getVazao ();
        float vazao = 0, buffer = 0;
        
        tempo = (tempo > barragens.size ()) ? barragens.size () : tempo;
        vazao = this.barragens.get (barragem).getVazao ();
        
        for (int j = 0/*barragem*/; j < tempo; ++j) {
        
            buffer = barragens.get (j).setNivelLago (vazao);
            
            if (buffer == -1) {
                
                System.out.println ("Nivel do lago abaixo dos 15%");
                buffer = 0;
            }
            
            vazao = barragens.get (j).getVazao () + buffer;
            //vazao = barragens.get (j).getVazao ();
        }
    }
    
    public void printarBarragens () {
        
        for (int i = 0; i < barragens.size (); ++i)
            System.out.println ("[" + i + "] " + barragens.get (i).getNomeBarragem ());
    }
    
    public void redistribuirAgua (int barragem, int quantidade, int tempo) {
        
        float vazao = 0, buffer = 0;
        
        tempo = (tempo > barragens.size ()) ? barragens.size () : tempo;
        vazao = abrirComportas (barragem, quantidade);
        
        for (int j = 0/*barragem*/; j < tempo; ++j) {
        
            buffer = barragens.get (j).setNivelLago (vazao);
            
            if (buffer == -1) {
                
                System.out.println ("Nivel do lago abaixo dos 15%");
                buffer = 0;
            }
            
            vazao = barragens.get (j).getVazao () + buffer;
            //vazao = barragens.get (j).getVazao ();
        }
    }
}