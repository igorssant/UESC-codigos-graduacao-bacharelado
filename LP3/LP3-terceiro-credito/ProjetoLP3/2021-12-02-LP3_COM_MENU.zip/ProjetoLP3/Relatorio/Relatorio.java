package ProjetoLP3.Relatorio;

import ProjetoLP3.Barragem.BarragemConcreta;
import ProjetoLP3.Rio.Rio;

public class Relatorio {
    
    private Rio rio;

    public Relatorio(Rio rio)
    {
        this.rio = rio;
    }

    //Verifca o nível do lago de uma Barragem.
    public void relatorioDeNivelLago(int barragemIndex)
    {
        BarragemConcreta barragem = this.rio.listarBarragens().get(barragemIndex);
        
        System.out.print("Rio: " + this.rio.getRioNome());
        System.out.println(barragem.getNomeBarragem() + "---" + barragem.getNivelLago());
    }

    public void verBarragens()
    {
        System.out.print("Rio: " + this.rio.getRioNome());
        for(int indice = 0; indice < rio.listarBarragens().size(); ++ indice)
        {
            System.out.println("[" + indice + "]"+rio.listarBarragens().get(indice).getNomeBarragem());
        }
    }

    //Verifica o nível do lago de todas as Barragens.
    public void relatorioDeNivelLago()
    {   
        System.out.print("Rio: " + this.rio.getRioNome());
        for(int indice = 0; indice < rio.listarBarragens().size(); ++ indice)
        {
            System.out.println("[" + indice + "]"+rio.listarBarragens().get(indice).getNivelLago());
        }
    }


    //Verifica o consumo de uma barragem.
    public void relatorioConsumo(int barragemIndex)
    {
        BarragemConcreta barragem = this.rio.listarBarragens().get(barragemIndex);

        System.out.print("Rio: " + this.rio.getRioNome());
        System.out.println(barragem.getNomeBarragem() + "---" + barragem.getConsumo());
    }


    //Verifica o consumo de todas as barragens.
    public void relatorioConsumo()
    {   
        System.out.print("Rio: " + this.rio.getRioNome());
        for(int indice = 0; indice < this.rio.listarBarragens().size(); ++indice)
        {
            System.out.println("[" + indice + "]"+rio.listarBarragens().get(indice).getConsumo());
        }       
    }


    //Verifica a vazão de uma barragem.
    public void relatatorioVazao(int barragemIndex)
    {
        System.out.println(this.rio.listarBarragens().get(barragemIndex));
    }


    //Verifica a vazão de todas as barragens.
    public void relatatorioVazao()
    {   
        System.out.print("Rio: " + this.rio.getRioNome());
        for(int indice = 0; indice < rio.listarBarragens().size(); ++ indice)
        {
            System.out.println("[" + indice + "]"+rio.listarBarragens().get(indice).getVazao());
        }    
    }

}
