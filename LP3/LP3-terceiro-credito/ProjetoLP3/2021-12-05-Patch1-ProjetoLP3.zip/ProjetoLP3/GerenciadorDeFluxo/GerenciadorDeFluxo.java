package ProjetoLP3.GerenciadorDeFluxo;

import ProjetoLP3.Rio.Rio;
import java.util.ArrayList;

public class GerenciadorDeFluxo {
    
    private ArrayList<Rio> rios;

    public GerenciadorDeFluxo () {
        
        rios = new ArrayList<Rio>();
    } // Contrutor vazio
    
    public GerenciadorDeFluxo (Rio rio) {
        
        rios = new ArrayList<Rio> ();
        this.rios.add (rio);
    }
    
    public void adicionarRio (Rio rio) {
        
        this.rios.add (rio);
    }

    public ArrayList<Rio> getRios()
    {
        return this.rios;
    }

    public Rio getRio(int rio)
    {
        return this.rios.get(rio);
    }
    
    public void removerRio (Rio rio) {
        
        this.rios.remove (rio);
    }

    public void removerRio(int rio)
    {
        this.rios.remove(rio);
    }
}