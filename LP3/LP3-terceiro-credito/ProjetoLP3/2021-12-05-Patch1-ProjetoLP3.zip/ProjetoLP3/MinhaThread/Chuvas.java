package ProjetoLP3.MinhaThread;

import ProjetoLP3.Barragem.BarragemConcreta;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Chuvas implements Runnable {
    
    // Runnable chuva = new Chuvas (); <== Como deve ser invocada 
    private BarragemConcreta barragem;
    private int tempo;
    private float quantidadeDeAgua, quantidadeAtual;
    
    public Chuvas (BarragemConcreta barragem, int tempo, float quantidadeDeAgua) {
        
        this.barragem = barragem;
        this.tempo = tempo;
        this.quantidadeDeAgua = quantidadeDeAgua;
        this.quantidadeAtual = this.barragem.getNivelLago ();
        Thread threadDeChuva = new Thread (this);
        threadDeChuva.start ();
    }

    @Override
    public void run () {
        
        System.out.println ("Começou a chover na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                System.out.println ("O nível de água na barragem " + barragem.getNomeBarragem () + " aumentou em " + this.quantidadeDeAgua + " litros!");
                Thread.sleep (1000 * tempo);
                barragem.setNivelLago(this.quantidadeAtual + this.quantidadeDeAgua);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        System.out.println ("Parou de chover na barragem " + barragem.getNomeBarragem () + "!!!");
    }
}