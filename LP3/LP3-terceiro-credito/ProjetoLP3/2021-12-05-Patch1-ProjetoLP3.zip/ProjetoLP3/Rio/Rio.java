package ProjetoLP3.Rio;

import java.util.ArrayList;

import ProjetoLP3.Barragem.BarragemConcreta;
import ProjetoLP3.Relatorio.Relatorio;

public class Rio
{      
   // private float volume;
   // private final float volumeMaximo;

    private String nome;

    private ArrayList<BarragemConcreta> barragens;
    private Relatorio meuRelatorio;
    
    public Rio(String nome)
    {
     //   this.barragens = new ArrayList<BarragemConcreta>();
     this.nome = nome;
     this.meuRelatorio = new Relatorio(this);
    }

    public Relatorio getMeuRelatorio()
    {
        return this.meuRelatorio;
    }

    public void setRioNome(String nome)
    {
        this.nome = nome;
    }

    public String getRioNome()
    {
        return this.nome;
    }

    //Adiciona água aos lagos das barragens.
    public void Chover(float quantidade)
    {
        for(BarragemConcreta barragem : barragens)
        {
           float atual = barragem.getNivelLago();
           barragem.setNivelLago(atual + quantidade);
       //    this.volume += (atual + quantidade);
        }

        //Verifica se houve excedentes.
        this.fluxoDeAgua();
    }

    public void Chover(float quantidade, int barragem)
    {
        float atual = this.barragens.get(barragem).getNivelLago();
        this.barragens.get(barragem).setNivelLago(atual + quantidade);
    }

    /*public float volumeAtual()
    {
        return this.volume;
    }*/

    //Pega a lista de todas as barragens construídas no rio.
    public  ArrayList<BarragemConcreta>listarBarragens()
    {
        return this.barragens;
    }

    //Adiciona nova barragem ao rio.
    public void addBarragem(BarragemConcreta barragem)
    {
        this.barragens.add(barragem);
    }

    //Adiciona nova barragem numa posição específica no rio.
    public void addBarragem(int posicao, BarragemConcreta barragem)
    {
        this.barragens.add(posicao, barragem);
    }

    //Remove uma barragem em uma possição no rio.
    public void removeBarragem(int posicao)
    {
        this.barragens.remove(posicao);
    }

    //Remove uma barragem do rio.
    public void removeBarragem(BarragemConcreta barragem)
    {
        this.barragens.remove(barragem);
    }

    public float consumoTotal()
    {
        float consumoTotal = 0;

        for(BarragemConcreta barragemConcreta : barragens)
        {
            consumoTotal += barragemConcreta.getConsumo();
        }

        return consumoTotal;
    }
    
    //Cálcula a redistribuição de água entre as barragens do rio.
    public void fluxoDeAgua () {
        
        float excedente = 0;
        
        for (BarragemConcreta barragem : barragens) {

            //Se a barragem não comportar a quantidade de água, ela é liberada para as próximas barragens.
            if (barragem.getNivelLago () >= barragem.getVolumeMaximoDoLago ()) {
                
                System.out.println("Atenção! Excesso de água na barragem\n\n");

                excedente = barragem.getNivelLago () - barragem.getVolumeMaximoDoLago ();
                barragem.setNivelLago (barragem.getVolumeMaximoDoLago ());
            }
            
            else {

                barragem.setNivelLago(barragem.getNivelLago () + excedente);
                break;
                
            }
                
        }   
        
    }
    
}