package menu;
import java.util.Scanner;

import Relatorio.Relatorio;
import java.util.Scanner;

public class MenuRelatorio
{   
    private Relatorio relatorio;

    public MenuRelatorio(Relatorio relatorio)
    {
        this.relatorio = relatorio;
    }

    public void nivelDosLagos()
    {
        System.out.println("Digite a barragem");

        relatorio.verBarragens();

        int indice = 0;

        relatorio.relatorioDeNivelLago(indice);
    }

    public void nivelTodosLagos()
    {
        relatorio.relatorioDeNivelLago();
    }

    public void verConsumoTodasBarragens()
    {
        relatorio.relatorioConsumo();
    }

    public void verConsumoBarragen()
    {   
        System.out.println("Digite o indice da barragem");
        relatorio.verBarragens();

        Scanner input = new Scanner(System.in);

        int indice = input.nextInt();

        relatorio.relatorioConsumo(indice);
    }

    public void menu()
    {   
        int opcao = 0;
        Scanner entrada = new Scanner(System.in);

        System.out.print("1)Para ver o nivel de todos os lagos\n2)Para ver o nivel de um lago\n"
        +"3)Para ver o consumo de uma barragem\n4)Para ver o consumo de todas as barragens\n5)Para sair\n>");

        opcao = entrada.nextInt();

        switch(opcao)
        {
            case 1:
            this.nivelTodosLagos();
            break;

            case 2:
            this.nivelDosLagos();
            break;

            case 3:
            this.verConsumoBarragen();
            break;

            case 4:
            this.verConsumoTodasBarragens();
            break;

            case 5:
            return;
        }
    }
}
