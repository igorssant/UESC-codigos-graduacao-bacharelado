package MinhaThread;

import Barragem.BarragemConcreta;
import java.util.logging.Level;
import java.util.logging.Logger;

import menu.MenuGerenciadorRios;

public class AbrirComporta implements Runnable {
    
    private BarragemConcreta barragem;
    private int tempo;
    private float numeroDeComportas;
    private boolean fechaOuAbre;
    private MenuGerenciadorRios gerenciadorRios;
    
    public AbrirComporta (int tempo, int numeroDeComportas, boolean fechaOuAbre, MenuGerenciadorRios gerenciadorRios) {
        
        this.tempo = tempo;
        this.numeroDeComportas = numeroDeComportas;
        this.fechaOuAbre = fechaOuAbre;
        this.gerenciadorRios = gerenciadorRios;
    }

    public void setBarragem( BarragemConcreta barragem)
    {
        this.barragem = barragem;
    }
    
    public void abrirComporta () {
        
        System.out.println (this.numeroDeComportas + " foram abertas na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                Thread.sleep (1000 * tempo);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "diminuiu para " + barragem.getNivelLago ());
    }
    
    public void fecharComporta () {
        
        System.out.println (this.numeroDeComportas + " foram fechadas na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                Thread.sleep (1000 * tempo);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        if (barragem.getVazao() > 0)
            System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "diminuiu para " + barragem.getNivelLago ());
        
        else
            System.out.println ("O nível de água da barragem " + barragem.getNomeBarragem () + "aumentou para " + barragem.getNivelLago ());
    }
    
    @Override
    public void run () {
        
        if (fechaOuAbre == true)
            abrirComporta ();
        
        else
            fecharComporta ();
    }

    public void menu()
    {
        BarragemConcreta barragemConcreta = this.gerenciadorRios.selecionarBarragem();
        this.setBarragem(barragemConcreta);
        Thread threadComporta = new Thread (this);
        threadComporta.start ();
    }

}