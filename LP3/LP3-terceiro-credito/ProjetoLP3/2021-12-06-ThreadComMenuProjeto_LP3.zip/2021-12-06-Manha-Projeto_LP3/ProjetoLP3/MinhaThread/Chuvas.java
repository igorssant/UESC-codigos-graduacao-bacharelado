package MinhaThread;

import Barragem.BarragemConcreta;
import java.util.logging.Level;
import java.util.logging.Logger;

import menu.MenuGerenciadorRios;

public class Chuvas implements Runnable {
    
    // Runnable chuva = new Chuvas (); <== Como deve ser invocada 
    private BarragemConcreta barragem;
    private int tempo;
    private float quantidadeDeAgua, quantidadeAtual;
    private MenuGerenciadorRios gerenciadorRios;
    
    public Chuvas ( int tempo, float quantidadeDeAgua, MenuGerenciadorRios gerenciadorRios) {
        
        this.tempo = tempo;
        this.quantidadeDeAgua = quantidadeDeAgua;
        this.quantidadeAtual = this.barragem.getNivelLago ();
        this.gerenciadorRios = gerenciadorRios;
    }

    public void setBarragem(BarragemConcreta barragem)
    {
        this.barragem = barragem;
    }

    @Override
    public void run () {
        
        System.out.println ("Começou a chover na barragem " + barragem.getNomeBarragem () + "!!!");
        
        try {
            
            for (int i = 0; i < tempo; ++i) {
                
                System.out.println ("O nível de água na barragem " + barragem.getNomeBarragem () + " aumentou em " + this.quantidadeDeAgua + " litros!");
                Thread.sleep (1000 * tempo);
                barragem.setNivelLago(this.quantidadeAtual + this.quantidadeDeAgua);
            }
        }
        
        catch (InterruptedException ex) {
            
            Logger.getLogger (Chuvas.class.getName ()).log (Level.SEVERE, null, ex);
        }
        
        System.out.println ("Parou de chover na barragem " + barragem.getNomeBarragem () + "!!!");
    }

    public void menu()
    {
        BarragemConcreta barragem = this.gerenciadorRios.selecionarBarragem();
        this.setBarragem(barragem);
        Thread threadDeChuva = new Thread (this);
        threadDeChuva.start ();
    }
}