import GerenciadorDeFluxo.GerenciadorDeFluxo;
import menu.*;
import Relatorio.Relatorio;
import Rio.Rio;

import java.util.Scanner;

public class App
{
    private GerenciadorDeFluxo gerenciador;
    private MenuGerenciadorRios menuGerenciadorRios;

    
    private Relatorio relatorio;
    private MenuRelatorio menuRelatorio;

    public App()
    {
        this.gerenciador = new GerenciadorDeFluxo();
        this.menuGerenciadorRios = new MenuGerenciadorRios(gerenciador);        
    }

    public void verGerenciador()
    {
        this.menuGerenciadorRios.menu();
    }

    public void verRelatorio()
    {
        int rio = 0;
        Scanner entrada = new Scanner(System.in);

        System.out.println("Selecione o rio:");

        this.menuGerenciadorRios.printRios();
        System.out.print(">");
        rio = entrada.nextInt();

        this.relatorio = new Relatorio(gerenciador.getRio(rio));
        this.menuRelatorio = new MenuRelatorio(relatorio);

        menuRelatorio.menu();


    }

    public static void main(String [] args)
    {
        int opcao = 0;
        Scanner entrada = new Scanner(System.in);
        
        App app = new App();

        do
        {
            System.out.print("1)Para Gerenciar os Rios\n2)Para ver os relatórios das barragens\n"+
            "3)Para sair\n>");
            opcao = entrada.nextInt();

            switch(opcao)
            {
                case 1:
                app.verGerenciador();
                break;

                case 2:
                app.verRelatorio();
                break;

                case 3:
                break;

                default:
                System.out.println("Opção incorreta");
                break;
            }
        }while(opcao != 3);
    }


}
