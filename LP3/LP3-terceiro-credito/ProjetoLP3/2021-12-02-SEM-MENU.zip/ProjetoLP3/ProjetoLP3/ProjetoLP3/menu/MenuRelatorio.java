package ProjetoLP3.menu;
import java.util.Scanner;

import ProjetoLP3.Relatorio.Relatorio;


public class MenuRelatorio
{   
    private Relatorio relatorio;

    public MenuRelatorio(Relatorio relatorio)
    {
        this.relatorio = relatorio;
    }

    public void nivelDosLagos()
    {
        System.out.println("Digite a barragem");

        relatorio.verBarragens();

        int indice = 0;

        relatorio.relatorioDeNivelLago(indice);
    }

    public void nivelTodosLagos()
    {
        relatorio.relatorioDeNivelLago();
    }

    public void verConsumoTodasBarragens()
    {
        relatorio.relatorioConsumo();
    }

    public void verConsumoBarragen()
    {   
        System.out.println("Digite o indice da barragem");
        relatorio.verBarragens();

        Scanner input = new Scanner(System.in);

        int indice = input.nextInt();

        relatorio.relatorioConsumo(indice);
    }
}
