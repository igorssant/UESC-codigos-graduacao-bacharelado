package ProjetoLP3.Barragem;

public interface Barragem
{
    public float abrirComportas(int numero);
    public void fecharComportas(int numero);
    public void adicionarComporta(int numero);
    public void removeComporta(int numero);

    public float getNivelLago();
    public int setNivelLago(float quantidade);

    public float getVazao();
    public void setVazao(float vazao);

    public float getConsumo();
    public void setConsumo(float consumo);
    
    public float getVolumeMaximoDoLago ();
}